Maison Matcha — Order Website
=============================

index.html   The complete website in one file (photos and logo built in).
             Upload it to any web host, or open it in a browser to try it.
             Ordering works the same as the Claude link; the Print / Save as PDF
             button only appears when it is hosted on your own website.

source/      For making changes:
  page.html  The page (menu, prices, text in Lao and English, design).
  images/    Logo and drink photos.
  build.py   Rebuilds index.html after a change:  python3 source/build.py

Settings near the top of the <script> in page.html:
  SHOP_WHATSAPP           Shop number that receives orders (8562051111711)
  DELIVERY_ENABLED        true / false
  OAT_PRICE, SWEETNESS    Oat milk price and sweetness levels
  STAFF                   Names in the dine-in staff list
  NUTTY_SIGNATURE_PRICE   Nutty Reserve prices for signature drinks
  PRODUCTS                Drinks, prices, photos and descriptions

Hosting: Netlify Drop, Cloudflare Pages, GitHub Pages or any static host.
Upload index.html, then point a subdomain such as order.maisonmatcha.live at it
from your Squarespace DNS settings (a CNAME record).

Lao and English text should be checked by a native speaker before customers use it.
