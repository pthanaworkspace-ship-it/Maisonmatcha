# Rebuilds ../index.html from page.html, embedding the photos so the site is one file.
# Usage: python3 build.py
import base64, re, os
here = os.path.dirname(os.path.abspath(__file__))
def uri(name):
    data = open(os.path.join(here, 'images', name + '.webp'), 'rb').read()
    return 'data:image/webp;base64,' + base64.b64encode(data).decode()
src = open(os.path.join(here, 'page.html'), encoding='utf-8').read()
body = re.sub(r'\{\{IMG:([a-z\-]+)\}\}', lambda m: uri(m.group(1)), src)
html = ('<!doctype html>\n<html lang="lo">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        '<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0}[hidden]{display:none!important}</style>\n'
        '</head>\n<body>\n' + body + '\n</body>\n</html>\n')
open(os.path.join(here, '..', 'index.html'), 'w', encoding='utf-8').write(html)
print('Built index.html', len(html) // 1024, 'KB')
