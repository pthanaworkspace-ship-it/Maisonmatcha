maisonmatcha.live — multi-page website
======================================

site/          Upload THIS folder to your Vercel project. It contains:
  index.html         Home            maisonmatcha.live
  menu/              Menu            maisonmatcha.live/menu
  matcha/            Our matcha      maisonmatcha.live/matcha
  order/             Order cart      maisonmatcha.live/order
  visit/             Visit us        maisonmatcha.live/visit
  404.html           Page not found
  assets/            Shared style, scripts, photos and logo
  vercel.json        Clean addresses (/menu instead of /menu/index.html)

Changing prices, drinks, staff names or the WhatsApp number:
  Edit site/assets/menu-data.js. The menu, matcha and order pages all read it.

Language: the ລາວ / EN switch is shared by every page and remembered on the device.

How to publish on Vercel:
  - If the current site was uploaded with the Vercel CLI: open a terminal in site/ and run
      vercel --prod
  - If it is connected to GitHub: replace the repository files with the contents of site/,
    then commit and push. Vercel publishes automatically.
  Squarespace DNS does not need any change.

source/        The files used to build site/ (only needed for larger redesigns).

Lao and English text should be checked by a native speaker before publishing.
